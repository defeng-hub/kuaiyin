#!/bin/bash

swag i -g init_router.go -dir app/admin/router --instanceName admin --parseDependency -o docs/admin
