#!/bin/bash
echo "go build"
go mod tidy
go build -o go-dcdg main.go
chmod +x ./go-dcdg
echo "kill go-dcdg service"
killall go-dcdg # kill go-admin service
nohup ./go-dcdg server -c=config/settings.dev.yml -a=true >> access.log 2>&1 & #后台启动服务将日志写入access.log文件
echo "run go-dcdg success"
ps -aux | grep go-dcdg
tail -f access.log