package version_local

func init() {
}

/**
开发者项目的迁移脚本放在这个目录里，init写法参考version目录里的migrate或者自动生成
*/
