#!/bin/bash
killall go-dcdg # kill go-admin service
echo "stop go-dcdg success"
ps -aux | grep go-dcdg