package actions

const (
	PermissionKey = "dataPermission"
)
