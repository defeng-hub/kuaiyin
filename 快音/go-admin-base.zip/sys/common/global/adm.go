package global

const (
	// Version go-admin version info
	Version = "2.1.2"
)

var (
	// Driver 数据库驱动
	Driver string
)
