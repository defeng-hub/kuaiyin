package global

const (
	LoginLog   = "login_log_queue"
	OperateLog = "operate_log_queue"
	ApiCheck   = "api_check_queue"
)
