package main

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"sort"
	"strings"
	"time"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

type LogEntry struct {
	Time time.Time
	SQL  string
}
type Cfg struct {
	Dsn      string
	FilePath string
}
type TbSyncLog struct {
	Id        int            `json:"id" gorm:"primaryKey;autoIncrement;comment:主键编码"`
	Env       string         `json:"env" gorm:"type:varchar(128);comment:环境"`
	LogName   string         `json:"logName" gorm:"type:varchar(128);comment:文件名"`
	Status    int            `json:"status" gorm:"type:tinyint(1);comment:同步状态"`
	LastError string         `json:"lastError" gorm:"type:varchar(256);comment:同步失败原因"`
	CreatedAt *time.Time     `json:"createdAt" gorm:"comment:创建时间"`
	UpdatedAt time.Time      `json:"updatedAt" gorm:"comment:最后更新时间"`
	DeletedAt gorm.DeletedAt `json:"-" gorm:"index;comment:删除时间"`
	CreateBy  int            `json:"createBy" gorm:"index;comment:创建者"`
	UpdateBy  int            `json:"updateBy" gorm:"index;comment:更新者"`
}

var cfgAry map[string]Cfg
var allowEnv string
var projtName = "base"

func init() {
	cfgAry = make(map[string]Cfg)
	cfgAry["dev"] = Cfg{
		Dsn:      "root:base@tcp(127.0.0.1:31279)/base?charset=utf8&parseTime=True&loc=Local&timeout=1000ms",
		FilePath: "/Users/" + projtName + "/logs/dev",
	}
	cfgAry["prod"] = Cfg{
		Dsn:      "root:base@tcp(127.0.0.1:3311)/base?charset=utf8&parseTime=True&loc=Local&timeout=1000ms",
		FilePath: "/opt/" + projtName + "/sys/logs/lan",
	}
	cfgAry["lan"] = Cfg{
		Dsn:      "root:base@tcp(127.0.0.1)/base?charset=utf8&parseTime=True&loc=Local&timeout=1000ms",
		FilePath: "/home/ftp/" + projtName + "/logs/prod",
	}
	allowEnv = "dev,lan,prod"
}

/**
* 从命令行接收两个参数，第一个为要读取的环境目录，第二为指定读取某一个文件，读取日志文件内容后回写到数据库
* 脚本每隔一个小时读取一次日志文件
* @param  arg1 要读取的环境
* @param  arg2 要读取的具体文件路径
* @Uesage: 1. go run main.go dev
* 		   2. go run main.go dev 2023110315.log
* @return nil
* @throws IOException
 */
func main() {
	//通过命令行参数获取文件路径
	var env string
	if len(os.Args) > 1 {
		env = os.Args[1]
		if !strings.Contains(allowEnv, env) {
			env = "dev"
		}
	} else {
		env = "dev"
	}
	fmt.Println(cfgAry[env])
	db, err := gorm.Open(mysql.Open(cfgAry[env].Dsn), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "", // 表名前缀（包含数据表和索引表）
			SingularTable: true,
		},
	})
	if err != nil {
		panic("Error : failed to connect database !")
	} else {
		fmt.Println("Info : db connect success")
	}

	var fileName string
	var syncLog TbSyncLog
	filePath := cfgAry[env].FilePath + "/"
	//如果有第二个参数，则读取指定文件
	if len(os.Args) > 2 {
		fileName = os.Args[2]
	} else {
		//读取目录下文件名列表，并按时间升序
		files, err := os.ReadDir(cfgAry[env].FilePath)
		if err != nil {
			fmt.Printf("Error : reading file list: %v\n", err)
			return
		}
		var fileNames []string
		if len(files) == 0 {
			fmt.Println("Info : file Dir list is empty")
			return
		}
		for _, file := range files {
			if file.IsDir() {
				continue
			}
			fileNames = append(fileNames, file.Name())
		}
		sort.Strings(fileNames)
		for _, name := range fileNames {
			//fmt.Println("Info : file name: " + name)
			//只处理1小时前的文件
			cmpName := time.Now().Add(-time.Hour).Format("2006010215") + ".log"
			if name >= cmpName {
				fmt.Println("Info : file is too young: " + name)
				continue
			}
			//查询文件名是否在tb_sync_log表中
			err = db.Where("log_name = ?", name).First(&syncLog).Error
			if errors.Is(err, gorm.ErrRecordNotFound) {
				//写入tb_sync_log表
				syncLog.Env = env
				syncLog.LogName = name
				syncLog.Status = 0
				err := db.Create(&syncLog).Error
				if err != nil {
					fmt.Printf("Error : sync_log Insert error:%s \r\n", err)
					return
				}
				fileName = name
				break
			} else {
				//查到的文件跳过
				syncLog = TbSyncLog{}
				continue
			}
		}
	}
	if fileName == "" {
		fmt.Println("Info : No sync log file !")
		return
	}
	// 1. 读取文件内容并解析成结构体，然后按时间排序
	fmt.Println("Info : Start to read file: " + fileName)
	isExit, logEntries := readAndParseLogFile(filePath + fileName)
	if !isExit {
		return
	}
	sort.Slice(logEntries, func(i, j int) bool {
		return logEntries[i].Time.Before(logEntries[j].Time)
	})
	for _, entry := range logEntries {
		err := db.Exec(entry.SQL).Error
		fmt.Println("Info : Exec SQL => " + entry.SQL)
		if err != nil {
			db.Model(&syncLog).Updates(map[string]interface{}{"status": 2, "last_error": err.Error()})
			fmt.Printf("Error : executing SQL: %v\n", err)
			return
		}
	}
	//更新tb_sync_log表状态
	err = db.Model(&syncLog).Update("status", 1).Error
	if err != nil {
		fmt.Printf("Error : update tb_sync_log error: %v\n", err)
		return
	}
	//移动文件到tmp目录
	err = os.Rename(filePath+fileName, "/tmp/"+fileName)
	fmt.Println("Info : Finish to sync log file ")
}
func readAndParseLogFile(filename string) (bool, []LogEntry) {
	//判断文件是否存在
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		fmt.Printf("Error : File not exist: %v\n", err)
		return false, nil
	}
	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("Error : File can't open : %v\n", err)
		return false, nil
	}
	defer file.Close()

	var logEntries []LogEntry
	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.Split(line, "\t")
		if len(parts) != 2 {
			fmt.Printf("Error : row format error : %v\n", err)
			continue
		}

		timeStr := parts[0]
		sqlStr := parts[1]

		t, err := time.Parse("2006-01-02 15:04:05.000", timeStr)
		if err != nil {
			fmt.Printf("Error : parsing time: %v\n", err)
			continue
		}

		logEntry := LogEntry{
			Time: t,
			SQL:  sqlStr,
		}
		logEntries = append(logEntries, logEntry)
	}

	if err := scanner.Err(); err != nil {
		fmt.Printf("Error : reading file: %v\n", err)
	}
	return true, logEntries
}
