import request from '@/utils/request'

// 查询BusBankCardtypes列表
export function listBusBankCardtypes(query) {
    return request({
        url: '/api/v1/bus-bank-cardtypes',
        method: 'get',
        params: query
    })
}

// 查询BusBankCardtypes详细
export function getBusBankCardtypes (id) {
    return request({
        url: '/api/v1/bus-bank-cardtypes/' + id,
        method: 'get'
    })
}


// 新增BusBankCardtypes
export function addBusBankCardtypes(data) {
    return request({
        url: '/api/v1/bus-bank-cardtypes',
        method: 'post',
        data: data
    })
}

// 修改BusBankCardtypes
export function updateBusBankCardtypes(data) {
    return request({
        url: '/api/v1/bus-bank-cardtypes/'+data.id,
        method: 'put',
        data: data
    })
}

// 删除BusBankCardtypes
export function delBusBankCardtypes(data) {
    return request({
        url: '/api/v1/bus-bank-cardtypes',
        method: 'delete',
        data: data
    })
}

