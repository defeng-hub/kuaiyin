import request from '@/utils/request'

// 查询BusSplit列表
export function listBusSplit(query) {
  return request({
    url: '/api/v1/bus-split',
    method: 'get',
    params: query
  })
}

// 查询BusSplit详细
export function getBusSplit(id) {
  return request({
    url: '/api/v1/bus-split/' + id,
    method: 'get'
  })
}

// 新增BusSplit
export function addBusSplit(data) {
  return request({
    url: '/api/v1/bus-split',
    method: 'post',
    data: data
  })
}

// 修改BusSplit
export function updateBusSplit(data) {
  return request({
    url: '/api/v1/bus-split/' + data.id,
    method: 'put',
    data: data
  })
}

// 删除BusSplit
export function delBusSplit(data) {
  return request({
    url: '/api/v1/bus-split',
    method: 'delete',
    data: data
  })
}

