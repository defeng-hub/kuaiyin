import request from '@/utils/request'

// 查询BusDataClean列表
export function listBusDataClean(query) {
  return request({
    url: '/api/v1/bus-data-clean',
    method: 'get',
    params: query
  })
}

// 查询BusDataClean详细
export function getBusDataClean(id) {
  return request({
    url: '/api/v1/bus-data-clean/' + id,
    method: 'get'
  })
}

// 新增BusDataClean
export function addBusDataClean(data) {
  return request({
    url: '/api/v1/bus-data-clean',
    method: 'post',
    data: data
  })
}

// 修改BusDataClean
export function updateBusDataClean(data) {
  return request({
    url: '/api/v1/bus-data-clean/' + data.id,
    method: 'put',
    data: data
  })
}

// 删除BusDataClean
export function delBusDataClean(data) {
  return request({
    url: '/api/v1/bus-data-clean',
    method: 'delete',
    data: data
  })
}

