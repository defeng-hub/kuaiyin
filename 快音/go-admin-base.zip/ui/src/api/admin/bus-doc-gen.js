import request from '@/utils/request'

// 查询BusDocGen列表
export function listBusDocGen(query) {
    return request({
        url: '/api/v1/bus-doc-gen',
        method: 'get',
        params: query
    })
}

// 查询BusDocGen详细
export function getBusDocGen (id) {
    return request({
        url: '/api/v1/bus-doc-gen/' + id,
        method: 'get'
    })
}


// 新增BusDocGen
export function addBusDocGen(data) {
    return request({
        url: '/api/v1/bus-doc-gen',
        method: 'post',
        data: data
    })
}

// 修改BusDocGen
export function updateBusDocGen(data) {
    return request({
        url: '/api/v1/bus-doc-gen/'+data.id,
        method: 'put',
        data: data
    })
}

// 删除BusDocGen
export function delBusDocGen(data) {
    return request({
        url: '/api/v1/bus-doc-gen',
        method: 'delete',
        data: data
    })
}

