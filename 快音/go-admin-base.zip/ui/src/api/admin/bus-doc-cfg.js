import request from '@/utils/request'

// 查询BusDocCfg列表
export function listBusDocCfg(query) {
  return request({
    url: '/api/v1/bus-doc-cfg',
    method: 'get',
    params: query
  })
}

// 查询BusDocCfg详细
export function getBusDocCfg(id) {
  return request({
    url: '/api/v1/bus-doc-cfg/' + id,
    method: 'get'
  })
}

// 新增BusDocCfg
export function addBusDocCfg(data) {
  return request({
    url: '/api/v1/bus-doc-cfg',
    method: 'post',
    data: data
  })
}

// 修改BusDocCfg
export function updateBusDocCfg(data) {
  return request({
    url: '/api/v1/bus-doc-cfg/' + data.id,
    method: 'put',
    data: data
  })
}

// 删除BusDocCfg
export function delBusDocCfg(data) {
  return request({
    url: '/api/v1/bus-doc-cfg',
    method: 'delete',
    data: data
  })
}

