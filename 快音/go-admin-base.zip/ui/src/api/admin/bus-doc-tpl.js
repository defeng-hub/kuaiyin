import request from '@/utils/request'

// 查询BusDocTpl列表
export function listBusDocTpl(query) {
    return request({
        url: '/api/v1/bus-doc-tpl',
        method: 'get',
        params: query
    })
}

// 查询BusDocTpl详细
export function getBusDocTpl (id) {
    return request({
        url: '/api/v1/bus-doc-tpl/' + id,
        method: 'get'
    })
}


// 新增BusDocTpl
export function addBusDocTpl(data) {
    return request({
        url: '/api/v1/bus-doc-tpl',
        method: 'post',
        data: data
    })
}

// 修改BusDocTpl
export function updateBusDocTpl(data) {
    return request({
        url: '/api/v1/bus-doc-tpl/'+data.id,
        method: 'put',
        data: data
    })
}

// 删除BusDocTpl
export function delBusDocTpl(data) {
    return request({
        url: '/api/v1/bus-doc-tpl',
        method: 'delete',
        data: data
    })
}

