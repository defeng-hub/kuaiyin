import request from '@/utils/request'

// 查询BusDocCase列表
export function listBusDocCase(query) {
  return request({
    url: '/api/v1/bus-doc-case',
    method: 'get',
    params: query
  })
}

// 查询BusDocCase详细
export function getBusDocCase(id) {
  return request({
    url: '/api/v1/bus-doc-case/' + id,
    method: 'get'
  })
}

// 新增BusDocCase
export function addBusDocCase(data) {
  return request({
    url: '/api/v1/bus-doc-case',
    method: 'post',
    data: data
  })
}

// 修改BusDocCase
export function updateBusDocCase(data) {
  return request({
    url: '/api/v1/bus-doc-case/' + data.id,
    method: 'put',
    data: data
  })
}

// 删除BusDocCase
export function delBusDocCase(data) {
  return request({
    url: '/api/v1/bus-doc-case',
    method: 'delete',
    data: data
  })
}

