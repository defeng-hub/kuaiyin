import request from '@/utils/request'

// 查询BusBankBincode列表
export function listBusBankBincode(query) {
    return request({
        url: '/api/v1/bus-bank-bincode',
        method: 'get',
        params: query
    })
}

// 查询BusBankBincode详细
export function getBusBankBincode (id) {
    return request({
        url: '/api/v1/bus-bank-bincode/' + id,
        method: 'get'
    })
}


// 新增BusBankBincode
export function addBusBankBincode(data) {
    return request({
        url: '/api/v1/bus-bank-bincode',
        method: 'post',
        data: data
    })
}

// 修改BusBankBincode
export function updateBusBankBincode(data) {
    return request({
        url: '/api/v1/bus-bank-bincode/'+data.id,
        method: 'put',
        data: data
    })
}

// 删除BusBankBincode
export function delBusBankBincode(data) {
    return request({
        url: '/api/v1/bus-bank-bincode',
        method: 'delete',
        data: data
    })
}

