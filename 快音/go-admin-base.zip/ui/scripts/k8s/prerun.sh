#!/bin/bash
kubectl create ns admin
kubectl create configmap nginx-frontend --from-file=./default.conf -n admin
